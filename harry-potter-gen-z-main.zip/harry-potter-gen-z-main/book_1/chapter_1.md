# Chapter One
## THE BOY WHO WASN'T UNALIVED

Mr. and Mrs. Dursley, of number four, Privet Drive, liked flexing that they were very basic, thank u. Tbh they were the last people you'd think would be sus, because they were all fax no printer.

Mr. Dursley was adulting at a firm called Grunnings, which made drills.

He was a dummy thiccc (w/ three Cs) man with hardly any neck, although he had an absolute unit of a mustache. Mrs. Dursley was a total Karen with zero chill and had hella neck, which came in very useful when she was stalking her neighbours and not minding her own.

The Dursleys had a future incel of a son named Dudley who they thought was the main character. The Dursleys were mostly thriving, but they also had lowkey tea which didn't pass the vibe check and their greatest fear was to get called out and cancelled. They were girlbossing too close to the sun and didn't think their clout could bounce back if their fam, the Potters, were revealed. Milf Lily Potter was Mrs. Dursley's sis, but Mrs. D had gone ghost; irl (no cap) Mrs. D fronted she didn't have a sis, because Lil and her deadbeat mans were straight up cringe. If the neighbors ever peeped the Potters, it'd be a big yikes. Lowkey the Dursleys knew the Potters had their own crotch goblin, too, but they'd never peeped. This bb was fr a solid reason 2 keep the in-laws yote; they didn't want Dudley mixing with a gross being like that.

When Mr. and Mrs. Dursley woke up on the dull, gray (fight me) Tuesday our lore opens, the cloudy overlay didnt vibe like strange and mysterious things would be happening all over the country. Mr. Dursley hummed as he picked out his most boring tie for work, and Mrs. Dursley spilled the tea as she was tryna put a screaming Dudley into his heckin high chair.

None of them noticed a chonky, tawny owl flutter past the window.

At half past eight, the chonklord that is Mr. Dursley picked up his briefcase, pecked Mrs. Dursley on the cheek, and tried to kiss Dudley goodbye but missed, because Dudley was losing it and yeeted his cereal at the walls. "Little Lad" chortled Mr. Dursley as he left the house. He got into his whip and backed out into the driveway of their basic asf house.

It was on that one edge of the street that you feel like you could accidentally hit the elbow of your car on that he noticed something sus --a cat popping off and reading a map. For a sec, Mr. Dursley didn't realize what he'd seen--then he jerked his head around to look again. There was a chonking tabby cat standing on the corner of Privet Drive, but there wasn't a map in sight. What could he have been thinking of? He must have accidentally picked up one of Mrs. Dursley's edibles that morning. Mr. Dursley blinked and stared at the chonking cat. It stared back. As Mr. Dursley drove around the corner and up the road, he watched the chonkers in his mirror. It was now reading the sign that said Privet Drive--no, _looking_ at the sign; cats couldn't read maps or signs. Periodt. Mr. Dursley gave himself a little shake and put the chonkers out of his thinking-organ. As he drove toward the town he had no thonks, head empty, except for some drills he had to sell. _Let's get this L O A F_, he thought.

But on the edge of town, drills were yeeted out of his mind by something else. As he sat in the morning traffic jam starterpack, he couldn’t help noticing that there seemed to be a lot of not-very-shady-at-all people about. People in cloaks. No cap. Mr. Dursley couldn’t bear people who dressed in cheugy clothes — the getups you saw on young people! He supposed this was some stupid new fashion. He drummed his fingers on the steering wheel and his eyes fell on a huddle of these weirdos standing quite close by. They were whispering excitedly together. Mr. Dursley was enraged to see that a couple of them weren’t young at all; why, that man had to be a boomer, and wearing an emerald-green cloak! The audacity of him! But then it struck Mr. Dursley that this was probably some silly stunt (a tiktok probs) — these people were obviously collecting for something… yes, that would be it. The traffic moved on and a few minutes later, Mr. Dursley arrived in the Grunnings parking lot, his mind back on drills. Mr. Dursley always sat with his back to the window in his office on the ninth floor. If he hadn’t, he might have found it harder to concentrate on drills that morning. He didn’t see the owls popping off in broad daylight, though people down in the street did; they pointed and gazed deceased as owl after owl sped overhead. Most of them had never seen an owl even at nighttime. Mr. Dursley, however, had a perfectly normal, owl-free morning. He had no chill and yelled at five different people. He made several important telephone calls and shouted a bit more. He was in a very good mood until lunchtime, when he thought he’d stretch his legs and walk across the road to buy himself a bun from the bakery. He’d forgotten all about the people in cloaks until he passed a group of them next to the Starbucks. He took a beeg look at them with unhappy as he passed. He didn’t know why, but they seemed kinda sus. This bunch were whispering excitedly, too, and he couldn’t see a single GoFundMe donation tin. It was on his way back past them, clutching a large doughnut in a bag, that he caught a few words of what they were saying. "The Potters, that’s right, that’s what I heard —"

" — bet, their boi, Harry —"

Mr Dursley felt like he'd been ratioed irl. He looked back at the whisperers and wondered if he should @ them, but thought better of it. Even a girlboss has his weak moments... and anyway, there were plenty of people called Potter with moots called Harry. There was no point in worrying his discord kitten- her sister was on both their DNI lists.

During that day, emo thoughts kept dabbing across Mr Dursley's mind. He later left the building and nearly sister slammed into someone just outside his door.

"Naurrr," he grunted, as the man nearly fell. However, he didn't seem triggered at all- instead, the funky little dude pressed the slay button. "So true, bestie! Even Muggles like u should slayy today, when The Sussiest Of Bakas has been canceled at last!"

And then the old man hugged Mr Dursley (real) and headed off.

Mr Dursley couldn't even find it in him to yeah fortnite 10k we're about to go down babey. He hurried to his car and The Fast and the Furious: Tokyo Drift—ed straight home.

As he pulled into the driveway the first thing he sister saw was the same chonk cat he'd seen in the morning, sitting on the wall.

"POV: You're on my DNI list," Mr Dursley spat at the cat as he walked inside.

His girlypop's day was swag asf. Dudley had learned to say "Naur" ("Just like his bestie!" cooed Mrs Dursley). When his fav oomf finally went afk, Mr Dursley went to the living room to watch sum news: "Last thing: birders everywhere are fighting for their lives right now. Them hooters hunt at night and avoid sunlight like nerds, but for some reason they've been invading our skies since sunrise. The science isn't science-ing." The newscaster smirked. "Weird af, bro. Now, Jim McGuffin, what that weather do, boyyyy? Anymore owl showers tonight?"

"Say less, Ted," said the weatherman, "Tbh, idk, but the birbs aren’t the only weird mullet daddies today. Viewers as far apart as Kent, Yorkshire, and Dundee have been tweeting that instead of the rain I promised yesterday, the sky is having shooting stars! Maybe they're celebrating Bonfire Night early. It will actually rain tonight though, but it’s about to be raining hands if mfs don’t stop calling about these damn birds."

Mr. Dursley 404 error-ed in his armchair. Shooting stars? Owls waking up and choosing violence? Sus boomers dressed in renfaire outfits? And spilling tea bout the Potters...

Mrs. Dursley came into the living room carrying two cups of tea. It was no good. He’d have to say something to her. He cleared his throat nervously. "Er – Petunia, my cotton swab, – you haven’t heard from your sis of late, maybe?"

As he had expected, Mrs. Dursley looked like she ate a lemon. After all, they ghosted her sis.

"Nope," she said sharply. "Why?"

"Cringey crap on the news," Mr. Dursley mumbled. "Owls... shooting stars... and there were a lot of edgelords in town today..."

"And?" snapped Mrs. Dursley.

"Well, I just thought... maybe... it was something to do with ... you know... _her crew_."

Mrs. Dursley sipped her tea through pursed lips. Mr. Dursley wondered whether he dared tell her that he’d heard the name "Potter." He decided he didn’t dare. Instead he said, as casually as he could, "Their crotch goblin – he’d be about Dudley’s age now, wouldn’t he?"

"Probs," huffed Mrs. Dursley.

"What’s his name again? Howard, isn’t it?"

"Harry. Nasty, cringe name, if you ask me."

"Oh, yeah," Mr. Dursley’s feels felt punched. "Legit."

He decided to stfu as they finna upstairs to catch some z’s. While Mrs. Dursley took off her face, Mr. Dursley lurked in the bedroom window overlooking the front garden. The floof was still there. It was staring down Privet Drive as though it were waiting for something.

Was he imagining things? Could all this have anything to do with the Potters? If it did... if it got out that they were related to a pair of – they would totes be cancelled.

The Dursleys got into bed. Mrs. Dursley crashed but Mr. Dursley couldn’t shake the intrusive thoughts. Finally he comforted himself that if the Potters were involved, there was no reason for them to invade the Dursley’s space. The Potters knew very well that he and his bae thought they were cringe and wanted nothing to do with their shenanigans... He couldn’t see how they could get all up in his business. They were probs safe and outta the way.

Hahahaha, nope.

Mr. Dursley was drifting off uneasily, but the floof outside was on high alert. Like a fuzzy statue with penetrating eyes, it stared unblinking at the far corner of Privet Drive. It showed superb chill as the world happened around it.

An ancient man appeared on the corner the cat had been protec on Privet Drive. He was tall, thin, and very old with a boss beard long enough to tuck into his belt. He was slaying in his long robes, a purple cloak that swept the ground, and high-heeled, buckled boots. His blu eyes were light, bright, and sparkling behind half-moon spectacles and his honker was long and crooked as though he had been punched in the face before. This ya boi, Albus Dumbledore.

Albus Dumbledore was super chill about the fact that he wasn’t wanted on this street. He was busy doing a self body cavity search until he felt the gaze of the catto. He chuckled and muttered, "I should have known."

He found his query, a silver cigarette lighter, flicked it open and clicked it. RIP the nearest street lamp. Ya boi got click happy and plunged the street into darkness. Now the nosy Nancy neighbors could see nothing on the block. The old man waltzed down the street to chill with the cat.

"Sup, Prof McGonagall?"

He turned to smile at the tabby who was now a human with the air of a CEO serious business woman. She be wearing square glasses exactly the shape of the markings on the cat. Her lewk was on fleek with an emerald green cloak and black hair in a tight bun.

"How did you know it was me?" she asked.

"Prof, cat’s don’t look like they planking."

"Brick walls aren’t comfy."

"Y u no party? There are like a dozen dank bangers I passed getting here."

Prof McGonagall sniffed angrily.

"Oh yes, everyone’s celebrating all right. High-key Muggles noticed. It was on their idiot box. Flocks of birbs... shooting stars... Muggles have eyes. Shooting stars down in Kent – bet that was Dedalus Diggle. Smooth brain."

"You can’t blame them," Dumbledore cooed. "This bull has been like 2020 for eleven years."

"Bet," said Prof McG irritably. "But that’s no reason to lose our chill. People be like herp derp, strutting like peacocks in broad daylight, not even dressed in Muggle swag, sipping tea."

She threw a sharp, sideways glance at Dumbledore here, as though hoping he was going to tell her something, but he didn’t so she went on. "A fine thing it would be if, on the very day You-Know-Who kicked rocks, the Muggles found out about us all. Did we really take a W?"

"Bet," said Dumbledore. "We have so much to be thankful for. Wanna lemon drop?"

"WTF?"

"A lemon drop. Muggle candy that is dank."

"Nope," Prof McG initiated ice queen mode. "Even if You-Know-Who has stepped off-"

"Girl, names are a thing. That trash is called Voldemort." Prof McG flinched but homeboi was unsticking lemon drops and gave no fucks. "Chillax, it’s just a name."

"Bet," Prof McG was exasperated but eyeing Dumbldore like a snacc. "But you’re the only one who could make Voldemort salty."

"Flattery will get you everywhere. Voldemort did have moves, though." Dumbledore said calmly.

"Fr you do, too, but you don’t flex."

"You make me blush."

Prof McG shot Dumbledore a sharp look and said, "The birbs are nothing next to this tea they be sipping. Legit what they say has me shook."

Prof McG had obvi got to the tea she was most hyped to spill, the real reason she had been vibing on a cold, hard wall all day, for neither as a floof nor as a woman had she looked as high-key invested as she did now. It was obvi that whatever "everyone" was saying, she wasn't gonna buy it until Dumbledore told her there was no cap. Homeboi, however, was choosing another lemon drop and didn’t answer.

"What they’re _saying_," she pressed on, " is that last night Voldemort spawned in Godric’s Hollow. He went to find the Potters. And that he unalived Lily and James Potter!"

Dumbledore sadded. Prof McG gasped.

"Lily and James... What the heck... I can't even... Oh, Albus..."

Dumbledore reached out and patted her on the shoulder. "I’m shook, too."

Professor McGonagall’s voice was shook as she went on. "That’s not all. They are saying he tried to unalive their son, Harry Potter, but he took an L and his power broke – and that’s why he’s gone."

Dumbledore noddled glumly.

"Legit?" faltered Professor McGonagall. "After all he’s done, he failed to unalive a babin and shm how did Harry survive?"

"We can only guess," said Dumbledore. "We may never know."

Prof McG wiped her eyes and got out her hand sanitizer. Dumbledore gave a great sniff as he took a bussin' watch from his pocket and checked it. It was a very sus watch. It had twelve hands but no numbers; instead, little planets were moving around the edge. It must have made sense to Dumbledore, though, because he put it back in his pocket and said, "Hagrid’s late. I bet he's the one who told you I’d be here, btw?"

"Bet," said Prof McG. "And I don’t suppose you’re going to tell me why you’re here of all places?"

"I’ve come to bring Harry to his aunt and uncle. They’re the only fam he has left now."

"You don’t mean – you can’t mean these Karens?!" cried Prof McG, jumping to her feet and pointing at number four. "Dumbledore – you can’t. I have been watching them all day. These basic fools aren't in the Same WhatsApp group! And their spawn – I saw him kicking his mother all the way up the street screaming for sweets. Harry Potter come and live here?!"

"Cope. It’s the best place for him," said Dumbledore firmly. "His aunt and uncle will be able to explain everything to him when he’s older. I’ve written them a letter."

"A _letter_?" repeated Prof McG faintly, sitting down on the wall. "Fr, Dumbledore, you think you can explain all this in a letter? These people will never understand him! He’ll be famous – legendary – I wouldn’t be shook if today was known as Harry Potter Day in the future – there will be books written about Harry – every child in our world will know his name!"

"Bet," said Dumbledore, looking super serious through his specs. "It would be enough to go to anyone's head. An influencer before he can walk and talk! Famous for something he won't even remember! Can't you see how much better off he'll be, growing up away from all that until he's ready to take it?"

Prof McG made fish faces like she was going to say something but thought better. She composed herself then said, "Bet, ikr. But how is the boy getting here, Dumbledore?" She eyed his cloak suddenly as though she thought he was transporting the babin.

"Hagrid's bringing him."

"You think it big brain to trust Hagrid with something as important as this?"

"I would trust Hagrid with my life," said Dumbledore.

"His heart is G.O.A.T.," said Prof McG grudgingly, "but you can't pretend he's not an airhead. He does tend to - what was that?"

A _vroom vroom_ sound broke the silence around them. It grew steadily louder as they looked up and down the street for some sign of a headlight; it swelled to a roar as they both looked up at the sky - a huge motorcycle fell out of the air and landed on the road in front of them.

If the motorcycle was huge, it was nothing compared to the beast of a man straddling it. He was almost twice as tall as a normal man and had some major BDE (big dick energy). His fluffy factor was a "Oh hell no" and so wild - long tangles of bushy black hair and beard hid most of his face, he had hands the size of hubcaps, and his feet in their leather boots were like baby dolphins. In his vast, muscular arms he was holding a bundle of blankets.

"Hagrid," said Dumbledore, sounding relieved. "Finally. Where'd you get the ride?"

"Borrowed it, Professor Dumbledore, sir," said the giant, gently disembarking from the bike. "Young Sirius Black lent it to me. I've got him, sir."

"Any issues?"

"Nope - house was almost destroyed, but I got him out all right before the Muggles started swarmin' around. He took a napper as we was flyin' over Bristol."

Dumbledore and Prof McG bent forward over the bundle of blankets. Inside, just visible, was the babin, sleepin. Under a tuft of jet-black hair over his forehead they could see a sus af cut, shaped like a bolt of lightning.

"Is that where-?" whispered Prof McG.

"Bet," said Dumbledore. "He'll have that scar forever."

"Cantcha fix it, Dumbledore?"

"Yeah, but no. Scars come in handy. I have one on my knee that is totes a map of the London Underground. Well - gimme, Hagrid - let's get this over with."

Dumbledore took Harry in his arms and turned toward the Dursley's house.

"Could I - could I say bye to him, sir?" asked Hagrid. He bent his great, shaggy head over Harry and gave him what must have been a very scratchy, whiskery kiss. Then, suddenly, Hagrid let out a noise like a wounded pupper.

"STFU" hissed Prof McG, "you'll wake the normies!"

"S-s-s-sowwy," sobbed Hagrid, taking out a large spotted handkercheif and burying his face in it. "But I c-c-can't stand it - Lily an' James unalived - an' an' poor lil' Harry off ter live with Muggles -"

"Yeah, no, yeah, tragic, but control yourself, Hagrid, or we'll be found," Prof McG whispered, patting Hagrid gently on the arm as Dumbledore stepped over the low garden wall and walked to the front door. He laid Harry gently on the doorstep, took a letter out of his cloak, tucked it inside Harry's blankets, and then came back to the other two. For a full minute the three of them stood and looked at the little bundle; Hagrid's shoulders shook, Prof McG blinked furiously, and the twinkling light that usually shone from Dumbledore's eyes seemed to have gone out.

"Whelp," said Dumbledore, finally, "that's that. Time to dip. We may as well go party hearty."

"Yeah," said Hagrid in a very muffled voice, "Finna give Sirius back his ride. G'night, Prof McG - Professor Dumbledore, sir."

Wiping his streaming eyes on his jacket sleeve, Hagrid swung himself onto the motorcycle and kicked the engine into life; with a roar it rose into the air and off into the night.

"See ya soon, G," said Dumbledore, nodding to her. Prof McG blew her nose in reply.

Dumbledore walked off into the night. On the corner he stopped and took out the silver Put-Outer. He clicked it once, and twelve balls of light sped back to their street lamps so that Privet Drive glowed suddenly orange and he could make out a tabby cat slinking around the corner at the other end of the street. He could just see the bundle of blankets on the step of number four.

"Gl, Harry," he murmured. He spun on his heel, swished his cloak, and vanished into the night.

A breeze ruffled the neat hedges of Privet Drive, super basic even under the stars, the very last place you would expect astonishing things to happen. Harry Potter cuddled up inside his blankies, sleepin soundly. One smol hand closed on the letter beside him and he slept on, not knowing he was special, not knowing he was famous, not knowing he would be woken in a few hours' time by Mrs. Dursley's scream as she opened the front door to put out the milk bottles, nor that he would spend the next few weeks being prodded and pinched by his cousin Dudley... He couldn't know that at this very moment, peeps meeting in secret all over the county gettin lit and saying in hushed voices: "To Harry Potter - the boy who wasn't unalived."
