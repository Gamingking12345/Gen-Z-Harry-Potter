# Chapter Five
## Diagon alley

Harry was on his sigma grindset and woke up hella early the next morning. He knew it was light outside, but kept his eyes closed.

"That ish was a dream" he said to himself. "I was def highkey tripping off that cuz ain't no way a giant named Hagrid told me I was going to a school for wizards. When I open my eyes I'll be back at the crib in that crusty cupboard"

There was suddenly a loud tapping noise.

*And there's Aunt Petunia knocking on the door*, Harry thought, his vibe sinking. Lowkey it had been a fire sesh.

Tap. Tap. Tap.

"Chill," Harry mumbled, "I'm getting up."

He sat up and Hagrid's heavy coat fell off him. The hut was full of sunlight, the storm was over, Hagrid was zooted on the ghetto couch, and there was an owl hitting its claw on the window, a boomer newspaper held in its beak.

Harry skrrted off the ground, so pumped he felt like he was floating on that zaza. Bro straight up went and yeeted that window open. The owl flew over and started going all goblin mode on Hagrid's coat.

"Ayo chill with that"

Harry tried to pwn that lil mf, but homie was having none o' that and was pissed af.

"Hagrid!" said Harry loudly. "There's an owl —"

"Pay him," Hagrid grunted into the sofa.

"What?"

"Buddy's tryin' cop the bag fer deliverin' the paper. Look in the pockets."

Hagrid's coat seemed to be made of nothing *but* pockets — bunches of keys, slug pellets, balls of string, peppermint humbugs, teabags . . . finally, Harry pulled out a handful of wack-looking coins.

"Give him five Knuts," said Hagrid sleepily.

"Bruh, Knuts?"

"The little bronze ones."

Harry counted out five little bronze coins, and the owl held out his leg so Harry could put the dough into a small leather pouch tied to it. Homie zoomed out the window as soon as he copped that bread.

Hagrid yawned loudly, sat up, and stretched.

"We gotta dip Harry, lots ter do today, gotta get up ter London an' cop all yer school shit and stuff."

Harry was turning over the wizard coins and looking at them. Bro just thought of something that totally killed the vibe.

"Um — Hagrid?"

"Sup?" said Hagrid, who was pulling on his huge off-white boots.

"I'm broke af — and you heard Uncle V last night . . . ain't no way buddy's dropping a dime. Bro stingy fr fr"

"No worries," said Hagrid, standing up and scratching his head. "D'yeh think yer parents got no stacks? They got those bandz fer G"

"But didn't their crib get clapped?"

"No way they keep that paper in the house for the ops, lil bro. Nah, we finna stop at Gringotts, stat. Wizards' bank. Grab a glizzy, they're not bad cold — plus that birthday cake still bussin'."

"Wizards have *banks*?"

"Just the one. Gringotts. Run by goblins."

Harry dropped the bit of glizzy he was holding.

"*Goblins?*"

"Yeah — so you'd be trippin' ter try an' rob them no cap. Never mess with goblins, Harry. Gringotts is the safest place in the world fer anything yeh want ter keep safe — 'cept maybe Hogwarts. Matter o' fact, I needa hit up Gringotts anyways. Fer my boi Dumbledore. Some Hogwarts shit." Hagrid puffed himself up. "My bro got me doing hella important ish. Picking your ass up — grabbing that ish from Gringotts — Buddy knows I got his back," Hagrid flexed on Harry, "So you chill to go?"

Harry followed Hagrid out onto the rock. The weather was hella nice and the ocean looked all nature'y. The boat Uncle V copped was still chillin' where they'd left it, but it had tons of water in after the storm. 

"How'd you get here?" Harry asked, looking around for another boat.

"Flew," said Hagrid.

"*Flew?*"

"Yeah, but we'll go back in this. Not s'pposed ter use magic now I've got yeh."

They sat down in the boat, Harry staring at Hagrid, trying to imagine him flying.

"Lowkey tho, rowing would be hella lame," said Hagrid, giving Harry another of his sideways looks. "But you're not gonna snitch are you?"

"Nah bruh, I gotchu" said Harry, tryna cop a glimpse of more magic. 

pg. 64 — chapter not finished yet
