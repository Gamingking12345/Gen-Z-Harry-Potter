# Chapter 2
## THE UNAPPEARING GLASS

It was like an eternity, like ten years, since the Dursleys had woken up to find their bb nephew on the front step, but Privet Drive was still super basic. The sun revealed the same front garden and shiny brass number four on the Dursley's front door; it crept into their living room, which was almost identical to the night when Mr. Dursley saw the fateful news report about them hooter birbs. Only the pics on the mantelpiece really showed how much time had passed. Ten years ago, there had been lots of pics of what looked like a chonky ball wearing different colored bonnets - but Dudley Dursley had the worst glo up ever, and now the pics showed a chonky blonde boy riding his first bicycle, on a carousel at the fair, playing Amogus with his dad, being xoxo-ed by his mom. The room lowkey didn't show that another boi lived in the house, too.

Yet Harry Potter was still there, catchin Zs at the moment, but not for long. His Aunt Petunia was awake and shrieked in her Karen voice for the first noise of the day.

"Up! Get up! Now!"

Harry woke with a start. His aunt tapped on the door again.

"Up!" she screeched. Harry heard her trodding toward the kitchen and then the sound of a frying pan being put on the stove. He rolled onto his back and tried to remember the dream he had been having. It was sick. There had been a flying motorcycle in it. It totes felt like deja vu.

His aunt teleported back outside the door.

"Are you up yet?" she demanded.

"Kinda," said Harry.

"No cap you need to look after the bacon. And don't you dare let it burn. I want everything gucci on Duddy's bday."

Harry groaned. So done.

"What did you say?" his aunt snapped through the door.

"Nothing, nothing..."

Dudley's bday - how could he have forgotten? Harry slowly unstuck himself from his bed and started hunting for socks. He found a pair under his bed and, after yoinking  a spider off one of them, put them on. Harry was used to spiders, because the dusty ass cupboard under the stairs was full of them, and that was his zone.

Once clothed he skirted his way down the hall into the kitchen. The table was smol beneath all Dudley's bday gifts. It looked as though Dudley had gotten the new chromebook he wanted, not to mention the second television and the racing bike. Harry was confusion as to why Dudley wanted a racing bike, as Dudley was a big heckin' chonker and hated gains - unless of course it involved throwing hands. Dudley's fave punching bag was Harry, but he couldn't often catch him. Harry didn't look it, but he was speedy af.

Prolly had something to do with living in a dutty cupboard, but Harry had always been smol and scrawny for his age. He looked the farthest from swole because all his fits were second hand clothes of Dudley's, and Dudley was fourish times as thicc as him. Harry has a gangly face, knobbly knees, black hair and bright green eyes (like Harry Styles). He wore circle glasses held together with a lot of Scotch tape bc of all the times he had caught Dudley's hands with his face. The only thing Harry liked about his lewk was a very thin scar on his forehead that was shaped like a bolt of lightning. He had had it as long as he could remember and thought it gave main character energy. Since his life was uninteresting asf the first question he could ever remember asking his Aunt Petunia was how he had gotten it.

"When your parents wrecked their whip and unalived." she had said. "And don't be askin questions."

Don't ask questions - that was the numero uno rule for living a basic life with the Dursleys.

Uncle Vernon vented in the kitchen as Harry was flippin' the bacon.

"Comb your hair!" he barked, by way of a morning greeting.

Bout once a week, Uncle Vernon peeped over the top of his tablet and shouted that Harry needed a new do. Harry's prolly had more haircuts than the rest of the bois in his class together, but his hair didn't give a fuck and simply grew that way - like an overfertilized chia pet.

Harry was frying eggs by the time Dudley vented in the kitchen with his birther. Dudley was a mini-me of Uncle Vernon. He had a chonky pink face, hardly any neck, smol watery blue eyes, and lotsa blonde hair that lay flat upon his fugly head. Aunt Petunia often said that Dudley looked like a bb angel - Harry often said that he looked like a rejected plus size cabbage patch doll. 

Harry put the feast of eggs and bacon on the table, which was supa hexagon hard bc there wasn't much room. Dudley, meanwhile, was countin' his presents. His privileged face fell.

"Thirty-six," he mathed, looking up at his mother and father. "That's two less than last year."

"Bae, you haven't counted Auntie Marge's present, cop a look, it's here under this big one from Mummy and Daddy."

"All right, thirty-seven then.", said Dudley, color changing to bright red. Harry, who was catching vibes of a huge Dudley bitchfit coming on, began chugging down his bacon as fast as possible in case Dudley yeeted the table over. 

Aunt Petunia saw the red flags, too, because she said quickly, "And we'll cop you another two presents while we're chillin' today. How's that, qt? Two more gifts. Is that aiight?"

Dudley strained as the wheels turned in his head, ever so slowly. "So I'll have thirty... thirty..."

"Thirty-nine, homeslice," said Aunt Petunia. 

"Oh." Dudley flopped down in the chair and grabbed the nearest present. "Aight then."

Uncle Vernon chuckled. 

"Lol lil dude just wants to get his dough's worth, just like his pop. That's mah boi, Dudley!" He ruffled Dudley's hair. 

At that moment the telephone went brrrrr and Aunt Petunia went to answer it while Harry and Uncle Vernon watched Dudley unwrap the racing bike, a video camera, a drone, sixteen new computer games, and a bluray player. He was ripping the paper off a gold wristwatch when Aunt Petunia came back from the telephone looking like somebody peed in her cornflakes. 

"Shitty news, Vernon," she said. "Mrs. Figg's clumsy ass broken her leg. She can't take him." She jerked her head in Harry's direction. 

Dudley's mouth fell open in horror, but Harry's heart did a ziggy. Every year on Dudley's bday, his parentals took him and a homeboy out for the day, to totes awesome adventure parks, bougie restaurants, or the dope movies. Every year, Harry was left behind with Mrs. F, a crazy old bat who lived two streets away. Harry hated it there. The whole house had a buttbreath smell of cabbage and Ms. F made him look at pics of all the kitties she'd ever hosted.

"Now what?" said Aunt Petunia, looking furiously at Harry as though he had schemed the whole thing. Harry knew he ought to give a shit that Mrs. F's leg was bruk, but it wasn't easy when he reminded himself that it would be a whole ass year before he had to look at Tibbles, Snowy, Mr. Paws, and Tufty again. 

"We could hit up Marge," Uncle Vernon suggested.

"You're kiddin', right? She hates the boi."

The Dursley's often spoke 'bout Harry like this, as though he wasn't there - or rather, as though he was something cringe that couldn't understand them, like a slug.

"What about what's-her-face, your homie - Yvonne?"

"On vacay in Majorca," snapped Aunt Petunia. 

"You could just dip and leave me here," Harry put in hopefully (he'd be able to watch what he wanted on Netflix for a change and maybe even troll the forums on Dudley's chromebook). 

Aunt Petunia looked as though she'd just swallowed a whole bag of sour skittles.

"And come back and find the house in ruins?" she bitched.

"I won't fuck up the house," said Harry, but they were boycotting him. 

"Ig we could take him to the zoo," said Aunt Petunia slowly. "... and lock him in the car..."

"That's my new whip, he ain't gonna chill in it alone..."

Dudley began to wail. Fact, he wasn't really crying - it had been literally forever since he had felt in-real-life emotions - but he knew if he screwed up his face and made unhappy noises, his birth giver would give him anything he wanted. 

"Diny Duddydums, don't cry. Mummy won't let him unbomb your bomb diggity day!" she cried, flinging her arms around him. 

"I ... don't... want... him... t-t-to come!" Dudley gasped for air between huge, pretend sobs. "He always sp-spoils everything!" He shot Harry a narsty grin through the gap in his mother's arms. 

Just then, the ding-dong rang - "Oh, for fucksake, they're here!" said Aunt Petunia frantically - and a sec later, Dudley's bff, Piers Polkiss, walked in with his mom. Piers was a scrawny boi with a face like a rat. He was usually the one who held people's arms behind their backs while Dudley cashed them outside. Dudley stopped bullshitting crying at once.

Half an hour later, Harry, who couldn't believe his luck, was sitting in the back of the Dursley's car with Piers n' Dudley, on the way to the zoo for the first time in his life. His aunt and uncle hadn't been able to big brain anything else to do with him, but before they'd left, Uncle Vernon had snatched Harry aside. 

"I'm warning you," he had said, putting his large purple face all up in Harry's grill. "I'm warning you now, boi - any sus bidness, anything at all - and you'll be in that cupboard from now until Christmas."

"I'm not going to do anything bro," said Harry. "Legit..."

But Uncle Vernon wasn't 'bout to be bamboozled and didn't believe him. No one ever did. 

The prob was, weird shit often happened around Harry and it was no good telling the Dursleys he deadass didn't do things. 

Once, Aunt Petunia, tired af of Harry coming back from Great Clips looking as though he hadn't been there at all, had taken a pair of kitchen scissors and cut his hair so short he was almost a full cueball except for his bangs, which she left "to hide that cringe disfigurement." Dudley had lamo at Harry, who spent a sleepless night imagining school the next day, where he was already razzed for his lack of style. Next morning, albeit, he had gotten up to find his do exactly as it had been before Aunt Petunia had sheared it off. He had been given a week in his cupboard for this, even though he had tried to explain that he didn't fuckin know how it had grown back so quickly. Not cool.

Another time, Aunt Petunia had been tryna force him into a heinous ass old sweater of Dudley's (brown with orange puff balls). The harder she tried to pull it over his head, the smaller it became, until it would prolly fit a barbie doll, but certainly wouldn't be Harry's drip. Aunt Petunia decided it must have shrunk in the wash and, to his swell relief, Harry didn't have to take the heat. 

On the other hand, he'd gotten into deep shit for being found on the roof of the school kitchens. Dudley's gang had been chasing him as usual, as much to Harry's gee wizzed as anyone else's, there he was vibin' on the chimney. The Dursley's received a very salty letter from Harry's headmistress straight up snitching to them that Harry had been parkouring school buildings. But all he'd tried to do (as he popped off at Uncle Vernon through the locked door of his cupboard) was jump behind the big trash cans outside the kitchen doors. Harry supposed that the wind must have snatched him mid-jump. 

But today, nada was going to go to shit. It was even worth being with Dudley and Piers to be spending the day somewhere that wasn't school, his cupboard, or Mrs. Figg's cabbage smelling living room. 

While he vrom vrommed, Uncle Vernon bitched to Aunt Petunia. He liked to bitch about things: people at work, Harry, the council, the bank, and Harry were just a few of his fav subjects. This morning it was motorcycles. 

"...roaring along like crackheads, the young gangstas," he said as a motorcycle overtook them.

"I had a dream 'bout a motorcyle," said Harry, remembering it suddenly. "It was flying."

Uncle Vernon nearly side swipped into the car in front. He whipped right around in his seat and yelled at Harry, his face like a giant beet with a mustache: "MOTORCYCLES DON'T FLY DUDE"

Dudley and Piers were laughing their asses off. 

"Lol I know they don't," said Harry. "It was only a dream."

Big yikes, he wished he had stfu. If there was one thing the Dursleys hated even more than him asking questions, it was his hollin' about anything acting sus, no matter if it was a dream or cartoon - they seemed to think he might get sus ideas. 

It was a v sunny Saturday and the zoo was asses and elbows with people. The Dursleys brought Dudley and Piers some B&J Ice cream at the entrance and then, because the smiling lady in the van asked Harry what he wanted before they could skirt him away, they bought him an off-brand lemon ice pop. It wasn't shitty either, Harry thought, licking it as they peeped a gorilla scratching its head who looked totes like Dudley, except that it wasn't blonde. 

Harry had had a dank morning something he hadn't had in a long time. He was careful to walk a lil way apart from the Dursleys so that he wouldn't get clocked by Dudley and Piers, who were starting to get bored of the animals by lunchtime. They ate in a zoo restaurant, and when Dudley had a bitchfit bc his kickerbocker glory didn't have enough ice cream on top, Uncle Vernon snatched him another one and Harry was allowed to finish the first. 

Harry felt, afterward, that he should have known it was all too bussin to last.

After lunch they went to the reptile house. It was nippy and dark in there, with lit windows all along the walls. Behind the glass, all sorts of lizards and sneks were crawling and slithering over bits of wood and stone. Dudley and Piers wanted to peep huge, poisonous, cobras and yolked, man-crushing pythons. Dudley quickly finded the largest danger noodle in the crib. It was clearly a bad bitch and could've wrapped its bod twice around Uncle Vernon's whip and hosed it--but rn it didn't look like it was feeling it. In fact, it was catchin' some z's.

Dudley standed with his nose pressed against the glass, deekin' at the glistening brown coils.

"Make it move," he boobed at his father. Uncle Vernon tapped on the glass, but the nope rope didn't give a fuck.

"Do it again," Dudley ordered (cause apparently he was too stoopy to do it himself). Uncle Vernon rapped the glass smartly with his chonky knuckles, but the snek was all good in the hood and slept on.

"This is boring," Dudley moaned. He shuffled away.

Harry skirted in front of the tank and looked intently at the nope rope. His wig would not be snatched if it had died of boredity itself--no besties except dingy people drumming their oily fingers on the glass trying to spam it all day long. It was worser than having a dumbass cupboard as a bedroom, where the only visitor was Aunt Petunia hammering on the door to wake your ass up; at least he got to peep the rest of the pad.

The snek suddenly opened its beady eyes. Slowly, v slowly, it uppied its head until its eyes were on a level wit Harry's.

It winked.

Harry was befuddled. At break neck speed he peeped around to see if the rest of the fam was coppin this too. They weren't. He peeped back at the snek and winked, too.

The snek boogied its head toward Uncle Vernon and Dudley, then raised its eyes to the ceiling (the sass was clear). It gave Harry a look that obvs said:

"These bitches do that all the time."

"Facts," Harry murmured through the glass, tho he was sus that the snek could acutally hear him. "It must be annoying af."

The snek nodded right quick.

"Where u from." Harry asked.

The snek jabbed its tail at a lil sign next to the glass. Harry squinted at it. 

Boa Constrictor, Brazil

"Damn was it gucci there?"

The nope rope jabbed its tail again and Harry read on: This specimen's parents were shipped and was born in the zoo. "Oh shit, I get u-- so you've neva been to Brazil."

As the snek zigged its head, a loud ass shout behind Harry snatched both of their wigs. "DUDLEY! MR.DURSLEY! COME AND COP A LOOK A THIS SNEK! YOU'LL BE TRIPPIN' WIT WHAT THIS SNEK IS DOING." 

Dudley came zoomin toward them.

"Get out the way," he said, clocking Harry in the ribs. Shook, Harry fell on the hard ass concrete floor. What came next happened so lickety-split everyone was like ???? -- one sec,  Piers and Dudley were basically groping the glass, the next, they had yeeted back with howls of horror.

Harry sat up and was shook; the glass front of the boa constrictor's tank had unappeared. The baddie snek was uncoilling itself and hauling ass out on too the floor. Bitches throughtout the reptile crib were quaking and skirting out the exits.

As the snek slid swiftly past him, Harry on god had heard a low, hissing voice say, "Aight imma head out to Brazil.... Thx, boyo."

The keeper of the reptile digs was shittin' kittens.

"But the glass," he kept saying, "where did the glass go?"

The zoo director himself made Aunt Petunia a cuppa strong sweet tea while he spammed sorries. Piers and Dudley could only gibber. Harry was one hundo p confident that the snek hadn't done shit except clown around, snapping at they heels as it skirted by, but by the time they were back in Uncle Vernon's whip, Dudley was flexing how it had nearly bitten off his leg, while Piers was capping that it had tried to squeeze him to death. But for sure the worst, for prolly only Harry, was Piers chilling out enough to snitch, "Harry was talking to it, right Harry?"

Uncle Vernon had a error 404 not found until Piers was safely out of the crib to start poppin off at Harry. He was so pressed he could hardly speak. He managed to say, "Go--cupboard--stay--no grub," before he collapsed into a chair, and Aunt Petunia had to sprint and snatch him a brandy so he could selective amnesia this event.

Harry lay in his emo cupboard forever, manifesting he had a watch. He couldn't sus out what time it was and couldn't be fo sho the Dursleys were big snoozin yet. Until they wer, he wan't gonna put his ah on the line to snatch some food from the kitchen.

He'd been thug-lifing with the Dursleys almost ten years, ten trash ass years, as long as he could remember, ever since he'd bin a bb and his parentals had unalived in a car crash. He had no memories of being in the whip. Sometimes, he big brained up a sus reality: a flashy flash of green light and a burnnning pain on his forehead. This, he supposed, was the crash, though it made no fuckin sense for a green light to be involved. He couldn't remember shit abt his parents. His aunt and uncle neva gossed abt them, and ofc he was gatekeeped from asking questions. There were no pics of them in the crib. 

When he had been a youngin, Harry had manifested of some unknown relation shownin up and snatchin him away, but it never happened; the Dursleys were his only fam. Yet sometimes he thought (more like manifested) that randoms in the street seemed to know him. Very sus randoms too. A lil man in a violet top hat had bowed to him once while out shopping with Aunt Petunia and Dudley. After interrogating Harry if he knew the man, Aunt Petunia had yeeted them out of the shop without buying anything. A crackhead-looking old women drippin in all green had waved merrily at him on a bus. A cueball man in a v long purple coat had actually shaken his hand in the street the other day and then dipped without a word. The sussiest thing about all these people was the way they seemed to vanish the sec Harry tried to get a closer look. 

At school, Harry had no homies. Everyone knew that Dudley's gang hated that odd Harry Potter in his baggy ass old clothes and broken glasses, and nobody finna disagreed wit Dudley's gang. 
