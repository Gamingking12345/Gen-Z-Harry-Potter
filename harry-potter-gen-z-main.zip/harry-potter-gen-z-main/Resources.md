## Some Resources That Can Help You:

#### [List of chapters in the Harry Potter books](https://harrypotter.fandom.com/wiki/List_of_chapters_in_the_Harry_Potter_books)
  - This is a list of all the chapters in the Harry Potter books.
     Can be used for coming up with names and for the illustrations
     at the beginning of each chapter.
     
#### [The Books](https://www.onlinereadfreebooks.com/en/author/j-k-rowling)
  - The actual books. 
  
#### [Chapter Art](https://www.harrypotterfanzone.com/chapter-art/)
  - All chapter illustrations from the books.

#### [Urban Dictionary](https://www.urbandictionary.com/)
  - Can be used for looking up slang and their definitions.

#### [Reddit post with additional slang](https://www.reddit.com/r/harrypotter/comments/w1ij8a/harry_potter_gen_z_edition/)
  - Will be used in the future.
